/**
 * Prompts Module - Sport-specific prompts
 * @module agents/common/prompts
 */

export { getPerplexityPrompt } from './perplexity.js';
export { getInsiderPrompt } from './insider.js';
