
import axios from 'axios';

const API_KEY = "sk-svcacct-fNiOxOwYY5YQWbApnwYZCO44E3KeXx4HZ1ZJEkVz_gYvxR9J4LwClzyRdmvWywoT3BlbkFJ4aE7_37XfYzgjwf8hIUL1jnPr6FJ96PJmHZPB6RTlEkAvZpxHALbvSnjzphd5AA";
const MODEL = "gpt-4o"; // Or gpt-4o-mini, gpt-3.5-turbo

console.log(`[OpenAI Test] Checking Key: ${API_KEY.slice(0, 15)}...`);

async function runTest() {
    try {
        const response = await axios.post(
            'https://api.openai.com/v1/chat/completions',
            {
                model: MODEL,
                messages: [{ role: "user", content: "Hello, are you active?" }],
                max_tokens: 10
            },
            {
                headers: {
                    'Authorization': `Bearer ${API_KEY}`,
                    'Content-Type': 'application/json'
                }
            }
        );
        console.log("✅ SUCCESS! Status:", response.status);
        console.log("   Response:", response.data.choices[0].message.content);
    } catch (error) {
        if (error.response) {
            console.log(`❌ FAILED. Status: ${error.response.status}`);
            console.log(`   Data:`, JSON.stringify(error.response.data, null, 2));
        } else {
            console.log(`❌ ERROR: ${error.message}`);
        }
    }
}

runTest();
